import pandas as pd

# Load your travel data CSV (make sure the file path is correct)
df = pd.read_csv("C:/Users/polep/Desktop/nit tour project/data/travel_data.csv")

# Define mood to tags mapping
mood_to_tag = {
    "happy": ["adventure", "romantic"],
    "sad": ["relaxation", "wellness"],
    "excited": ["adventure", "wildlife"],
    "calm": ["wellness", "romantic"]
}

def recommend_destinations(mood, budget, days):
    tags_for_mood = mood_to_tag.get(mood.lower(), [])

    recommended = []
    for _, row in df.iterrows():
        # Check if the destination tags match any tag related to the mood
        dest_tags = row['tags'].split("|")  # split if multiple tags separated by '|'
        # Check if any tag matches mood tag
        if any(tag in tags_for_mood for tag in dest_tags):
            total_cost = row['cost_per_day'] * days
            if total_cost <= budget:
                recommended.append({
                    "destination": row['destination'],
                    "tags": row['tags'],
                    "cost_per_day": row['cost_per_day'],
                    "total_cost": total_cost
                })
    return recommended

