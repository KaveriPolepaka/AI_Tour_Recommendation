from recommend import recommend_destinations

# Input
user_mood = "happy"
user_budget = 15000
user_days = 3

# Get recommendations
results = recommend_destinations(user_mood, user_budget, user_days)

# Print output
for rec in results:
    print(f"\nDestination: {rec['destination']}")
    print(f"Tag: {rec['tags']}")
    print(f"Estimated Total Cost: ₹{rec['cost_per_day'] * user_days}")
