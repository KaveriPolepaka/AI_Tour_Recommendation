# app.py
from fastapi import FastAPI
from pydantic import BaseModel
from recommend import recommend_destinations
from utils import get_hotels, get_food

app = FastAPI()

class UserInput(BaseModel):
    mood: str
    budget: int
    days: int
    location: str = None

@app.post("/recommend/")
def recommend(user: UserInput):
    destinations = recommend_destinations(user.mood, user.budget, user.days)
    if not destinations:
        return {"message": "No destinations found within your budget and mood."}
    
    dest = destinations[0]  # take first best match
    hotel_budget = user.budget // user.days
    hotels = get_hotels(dest, hotel_budget)
    food = get_food(dest)
    return {
        "recommended_destinations": destinations,
        "hotels": hotels,
        "food": food
    }
