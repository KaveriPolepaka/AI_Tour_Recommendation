# utils.py
import pandas as pd

hotel_df = pd.read_csv("data/hotels.csv")
food_df = pd.read_csv("data/food.csv")

def get_hotels(destination, max_budget):
    return hotel_df[
        (hotel_df["destination"] == destination) &
        (hotel_df["cost_per_night"] <= max_budget)
    ].to_dict(orient="records")

def get_food(destination):
    return food_df[food_df["destination"] == destination].to_dict(orient="records")
